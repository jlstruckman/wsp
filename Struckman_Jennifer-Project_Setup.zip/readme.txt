https://github.com/jlstruckman/wsp
http://jlstruckman.github.com/wsp/